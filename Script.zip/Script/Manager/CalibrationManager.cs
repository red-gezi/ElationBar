using Sirenix.OdinInspector;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class CalibrationManager : MonoBehaviour
{
    CharaManager playerManager;

    public Transform modelHeadPoint;
    public Transform modelLeftHandPoint;
    public Transform modelRightHandPoint;
    private void Awake() => playerManager = GetComponent<CharaManager>();
    [Header("У׼˫������")]
    public Vector3 LeftHandPointPosBias;
    public Vector3 LeftHandPointEulaBias;
    public Vector3 RightHandPointPosBias;
    public Vector3 RightHandPointEulaBias;
    [Button("У׼˫���ֵ�λ")]
    public void CalibrationRightHand()
    {
        LeftHandPointPosBias = playerManager.leftHandPoint.position - modelLeftHandPoint.position;
        LeftHandPointEulaBias = modelLeftHandPoint.eulerAngles - playerManager.leftHandPoint.eulerAngles;
    }
    void Update()
    {
        if (modelHeadPoint!=null)
        {
            playerManager.head.transform.position = modelHeadPoint.transform.position;

        }
        if (modelLeftHandPoint != null)
        {
            playerManager.leftHandPoint.transform.position = modelLeftHandPoint.transform.position + LeftHandPointPosBias;
            playerManager.leftHandPoint.transform.eulerAngles = modelLeftHandPoint.transform.eulerAngles + LeftHandPointEulaBias;
        }
        if (modelRightHandPoint != null)
        {
            playerManager.rightHandPoint.transform.position = modelRightHandPoint.transform.position + RightHandPointPosBias;
            playerManager.rightHandPoint.transform.eulerAngles = modelRightHandPoint.transform.eulerAngles + RightHandPointEulaBias;
        }
    }
}
