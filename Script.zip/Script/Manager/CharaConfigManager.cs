using Sirenix.OdinInspector;
using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

public class CharaConfigManager : GeziBehaviour<CharaConfigManager>
{
    [Header("ģ��")]
    public GameObject template;
    private void Start()
    {
        foreach (Transform model in transform.GetChild(0))
        {
            model.gameObject.SetActive(false);
        }
    }
#if UNITY_EDITOR
    [Button("����������")]
    public void CreatModel(GameObject chara, BodyType bodyType)
    {
        //�ر���������ɼ���
        foreach (Transform model in transform.GetChild(0))
        {
            model.gameObject.SetActive(false);
        }
        //����ģ��������ʵ��
        GameObject newModel = Instantiate(template, template.transform.parent);
        newModel.SetActive(true);
        newModel.name = chara.name;
        GameObject oldChara = newModel.transform.GetChild(0).gameObject;
        //�滻ģ��
        GameObject newChara = Instantiate(chara, oldChara.transform.parent);
        newChara.name = chara.name + "ģ��";
        newChara.transform.position = oldChara.transform.position;
        newChara.transform.localScale = oldChara.transform.localScale;
        Animator charaAnimator = newChara.GetComponent<Animator>();
        charaAnimator.runtimeAnimatorController = oldChara.GetComponent<Animator>().runtimeAnimatorController;
        charaAnimator.applyRootMotion = false;
        //װ��ģ���������
        var playerManager = newModel.GetComponent<CharaManager>();
        newChara.transform.SetAsFirstSibling();
        playerManager.currentPlayerChara = Enum.Parse<Chara>(chara.name);
        Debug.Log($"############################################��ʼ��������ģ���Զ�������############################################");
        Debug.Log($"��ʼ����ͷ��IK");
        var ikManager = newChara.AddComponent<IKManager>();
        ikManager.target = playerManager.focusPoint.transform;
        //װ�����������������
        newChara.AddComponent<FaceManager>();
        //װ��MMD���
        var mmdModel = newChara.AddComponent<MMD4MecanimModelImpl>();
        Debug.Log($"��ʼ����ģ������");
        string directory = System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(chara));
        mmdModel.modelFile = AssetDatabase.LoadAssetAtPath<TextAsset>(System.IO.Path.Combine(directory, chara.name + ".model.bytes"));
        mmdModel.vertexFile = AssetDatabase.LoadAssetAtPath<TextAsset>(System.IO.Path.Combine(directory, chara.name + ".vertex.bytes"));
        Debug.Log("ģ���ļ�����" + (mmdModel.modelFile ? "�ɹ�" : "ʧ��"));
        mmdModel.physicsEngine = MMD4MecanimModelImpl.PhysicsEngine.BulletPhysics;
        //У׼ͷ����˫�ֹؼ���λ��
        var modelHeadPoint = mmdModel.GetComponentsInChildren<Transform>().FirstOrDefault(child => child.name.Contains("joint_Head"));
        var modelLeftHandPoint = mmdModel.GetComponentsInChildren<Transform>().FirstOrDefault(child => child.name.Contains("joint_LeftWrist"));
        var modelRightHandPoint = mmdModel.GetComponentsInChildren<Transform>().FirstOrDefault(child => child.name.Contains("joint_RightWrist"));
        newModel.GetComponent<CalibrationManager>().modelHeadPoint = modelHeadPoint;
        newModel.GetComponent<CalibrationManager>().modelLeftHandPoint = modelLeftHandPoint;
        newModel.GetComponent<CalibrationManager>().modelRightHandPoint = modelRightHandPoint;
        if (modelHeadPoint == null) Debug.LogWarning("���棺ͷ����λδ�ҵ�");
        if (modelLeftHandPoint == null) Debug.LogWarning("���棺���ֵ�λδ�ҵ�");
        if (modelRightHandPoint == null) Debug.LogWarning("���棺���ֵ�λδ�ҵ�");
        //��������
        Debug.Log($"��ʼ���ÿ���");
        //ѭ������ģ�ͣ���ȡ�沿�����Ͳ�����
        FindComponentInChild(newChara, newChara.transform, playerManager);
        if (ikManager != null)
            DestroyImmediate(oldChara);
        Debug.Log($"�������");
        static void FindComponentInChild(GameObject currentChara, Transform currentTransform, CharaManager playerManager)
        {
            foreach (Transform item in currentTransform)
            {
                if (item.TryGetComponent(out SkinnedMeshRenderer renderer))
                {
                    playerManager.charaMesh.Add(renderer);
                    //�����沿����
                    if (renderer.sharedMesh.blendShapeCount > 0)
                    {
                        var keys = Enumerable.Range(0, renderer.sharedMesh.blendShapeCount)
                                                .Select(i => renderer.sharedMesh.GetBlendShapeName(i))
                                                .ToList();
                        var a = keys.IndexOf(keys.Where(key => key.Contains("��")).OrderBy(key => key.Length).FirstOrDefault());
                        var e = keys.IndexOf(keys.Where(key => key.Contains("��")).OrderBy(key => key.Length).FirstOrDefault());
                        var i = keys.IndexOf(keys.Where(key => key.Contains("��")).OrderBy(key => key.Length).FirstOrDefault());
                        var o = keys.IndexOf(keys.Where(key => key.Contains("��")).OrderBy(key => key.Length).FirstOrDefault());
                        var u = keys.IndexOf(keys.Where(key => key.Contains("��")).OrderBy(key => key.Length).FirstOrDefault());
                        FaceManager faceManager = currentChara.GetComponent<FaceManager>();
                        faceManager.skinnedMeshRenderer = renderer;
                        faceManager.a = a;
                        faceManager.e = e;
                        faceManager.i = i;
                        faceManager.o = o;
                        faceManager.u = u;
                        Debug.LogWarning($"����ƥ����a{a} e{e} i{i} o{o} u{u}");
                    }
                }
                else
                {
                    FindComponentInChild(currentChara, item, playerManager);
                }
            }
        }
        //����ģ��shader
    }
#endif

    [Button("�л���ǰ����")]
    public async void SelectModel(Chara chara)
    {
        //�л�����ͬ�����������
        if (GameManager.PlayerChara == chara)
        {
            return;
        }
        CharaManager oldModel = GameManager.CurrentConfigChara;
        CharaManager newModel = null;
        foreach (Transform model in transform.GetChild(0))
        {
            bool isTarget = model.name == chara.ToString();
            if (isTarget)
            {
                newModel = model.GetComponent<CharaManager>();
            }
        }

        var oldModelMaterials = oldModel?.charaMesh.SelectMany(mesh => mesh.materials).ToList();
        newModel.gameObject.SetActive(true);
        GameManager.PlayerChara = chara;
        GameManager.CurrentConfigChara = newModel.GetComponent<CharaManager>();
        ConfigManager.SetConfigData(data => data.PlayerChara, chara);
        await CustomThread.TimerAsync(2, (progress =>
        {
            //�ɵĻ�����ʧ
            if (oldModelMaterials != null)
            {
                foreach (var material in oldModelMaterials)
                {
                    material.SetInt("_IsHide", 1);
                    material.SetFloat("_Dissolve", progress);
                };
            }
            //�µĽ�������
            var newModelMaterials = newModel.charaMesh.SelectMany(mesh => mesh.materials).ToList();
            foreach (var material in newModelMaterials)
            {
                material.SetInt("_IsHide", 0);
                material.SetFloat("_Dissolve", progress);
            };
        }));
        oldModel?.gameObject.SetActive(false);
    }
}
